<?php 
namespace App\Models;
use CodeIgniter\Model;
class Etudiant extends Model
{
    protected $table = "Etudiant";
    protected $allowedFields = ["nom", "prenom"];
    
}
?>