<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Main::index');
$routes->post('/insertion', 'Main::inserer');
$routes->get('/list', 'Main::afficherList');
$routes->get('/suppression/(:num)', 'Main::supprimer/$1');
$routes->get('/modification/(:num)', 'Main::modifier/$1');
$routes->post('/modifier/(:num)','Main::modification/$1');
$routes->get('/modifier/(:num)','Main::modification/$1');
$routes->get('/attribution/(:num)', 'Main::attribuer/$1');
$routes->get('/desattribution/(:num)', 'Main::desattribuer/$1');
$routes->get('/changement/(:num)/(:num)', 'Main::changer/$1/$2');
$routes->get('/donnation/(:num)/(:num)', 'Main::donner/$1/$2');
$routes->get('/desattribution/(:num)', 'Main::desattibuer/$1');
