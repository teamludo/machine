<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajout</title>
    <style>
        /* *{
        margin:0px;
        padding: 0px;
        box-sizing: border-box;
        font-family: Arial, Helvetica, sans-serif;
        } */
        body {
        height: 100vh;
        font-family: 'Roboto', sans-serif;
        background: linear-gradient(to right, #7200d0, rgb(0,119,255));
        display: flex;
        justify-content: center;
        align-items: center;
        }
        form{
            width: 90%;
            max-width: 1000px;
            height: auto;
        }
        .container{
            width: 100%;
            height: auto;
            background-color: #ffffff;
            border-radius: 10px;
            display: grid;
            grid-template-columns: 1fr 1fr;
            grid-gap: 5vw;
        }

        .container-img {
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .container-img img {
            width: 80%;
            max-width: 350px;
            height: auto;
        }

        .container-form {
            display: grid;
            grid-template-columns: 1fr;
            grid-gap: 20px;
            padding: 5% 5%;
        }

        .input-container {
            background-color: #e5e5e5;
            display: flex;
            align-items: center;
            padding: 5px;
            height: 45px;
            border-radius: 30px;
            width: 90%;
        }
        .liste-container{
            width: 90%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 20px;
        }
        .liste-container a{
            text-decoration: none;
            font-size: 18px;
        }
        .input-container:hover {
            background-color: #eaeaea;
        }

        .input-field {
            color: #6b6b6b;
            background-color: inherit;
            width: 100%;
            border: none;
            font-size: 1.3rem;
            font-weight: 400;
            padding-left: 30px;
        }

        .input-field:hover,
        .input-field:focus {
            outline: none;
        }

        #input-submit {
            background-color: blueviolet;
            padding-left: 0;
            font-weight: bold;
            color: white;
            text-transform: uppercase;
            height: 45px;
            border-radius: 30px;
            width: 90%;
        }

        #input-submit:hover {
            background-color: rgb(0,119,200);
            transition: background-color 1s;
            cursor: pointer;
        }

        h1{
            text-align: center;
        }
    </style>
</head>
<body>
<form action="http://www.machine.mg/index.php/insertion" method="post">
    <div class="container">
        <div class="container-img">
            <img src="icon.png" alt="icon pc"/>
        </div>
        <div class="container-form">
            <h1>AJOUT PC</h1>
            <div class="input-container">
                <i class="label"></i>
                <input placeholder="Adresse Mac" name="mac" id="mac" class="input-field"/>
            </div>
            <div class="input-container">
                <i class="label"></i>
                <input placeholder="Adresse IP" name="ip" id="ip" class="input-field"/>
            </div>
            <div class="input-container">
                <i class="label"></i>
                <input placeholder="Numéro de série" name="serie" id="serie" class="input-field"/>
            </div>
            <div class="input-container">
                <i class="label"></i>
                <input placeholder="Pan" name="pan" id="pan" class="input-field"/>
            </div>
            <div class="input-container">
                <i class="label"></i>
                <input placeholder="Etat" name="etat" id="etat" class="input-field"/>
            </div>
            <div class="input-container">
                <i class="label"></i>
                <input placeholder="Hostname" name="host" id="hostname" class="input-field"/>
            </div>
            <input type="submit" value="Enregistrer" id="input-submit" class="input-field"/>
            <div class="liste-container">
                <a href="/index.php/list">lister les machine</a>
                <?php
                if (isset($message)){
                    echo $message;
                }
                ?>
            </div>
        </div>
    </div>
</form>
</body>
</html>