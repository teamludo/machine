<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Affichage</title>
    <style>
        *{
        margin:0px;
        padding: 0px;
        box-sizing: border-box;
        font-family: Arial, Helvetica, sans-serif;
        }
        body{
            height: 100vh;
            width: 100vw;
            background:linear-gradient(to right,blueviolet,rgb(0, 119, 255));
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .table{
            border-collapse: collapse;
            min-height: 80%;
            width: auto;
        }
        .div-tr{
            height: auto;
            width: auto;
            border-collapse: collapse;
        }
        .div-table{
            height: auto;
            width: auto;
            margin-bottom: 40px;
            overflow: auto;
        }

        .tr-init{
            height: 50px;
            width: auto;
            background-color: rgb(92, 43, 226);
            margin:0px;
            font-weight: bold;
            color:white;
        }
        tr{
            position: relative;
        }
        tr::after{
            position: absolute;
            content: "";
            top: 0;
            left: 0;
            background-color:  rgb(92, 43, 226);
            height: 100%;
            width: 0px;
        }
        tr:hover{
            background-color: rgba(190, 188, 188, 0.534);
        }
        .tr-init:hover{
            background-color: rgb(92, 43, 226);
        }
        tr:hover::after{
            width: 3px;
        }
        td{
            height: 50px;
            width: calc(85vw/7);
            margin:0px;
            text-align: center;
            border-radius: 10px;
        }
        .td-action{
            width: 18vw;
        }
        a{
            height: 100px;
            width: 100px;
        }
        .btn-action{
            height: 20px;
            width: 70px;
            padding-left: 5px;
            padding-right: 5px;
            font-weight: bold;
            background-color: rgb(92, 43, 226);
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 12px;
        }
        .div{
            height: 85%;
            width: 94%;
            background-color: white;
            box-shadow: 0px 0px 20px rgb(82, 79, 79);
            border-radius: 10px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        h1{
            color: rgb(92, 43, 226);
            margin-bottom: 30px;
            margin-top: 50px;
        }
        .princ{
            height: 80%;
            width: 100%;
            display: flex;
            flex-direction: column;
            align-items: center;
        }
    </style>
</head>
<body>
    <div class="div">
        <div class="princ">
            <h1>LISTES DES PC</h1>
            <table class="div-tr">
                <tr class="tr-init">
                    <td>MAC</td>
                    <td>IP</td>
                    <td>SERIE</td>
                    <td>PAN</td>
                    <td>ETAT</td>
                    <td>HOSTNAME</td>
                    <td class="td-action">ACTION</td>
                </tr> 
            </table>    
            <div class="div-table">
                <table class="table">
                    <?php foreach($machine as $m):?>
                        <tr>
                        <td><?=$m['mac']?></td>
                        <td><?=$m['ip']?></td>
                        <td><?=$m['serie']?></td>
                        <td><?=$m['pan']?></td>
                        <td><?=$m['etat']?></td>
                        <td><?=$m['hostname']?></td>
                        <td class="td-action">
                        <?php
                            if ($m['attribution']=="non"){
                                echo "<a href='/index.php/attribution/".$m['id']."'><button class='btn-action'>Attribuer</button></a>";
                            }
                            else {
                                echo "<a href='/index.php/desattribution/".$m['id']."'><button class='btn-action'>Desattribuer</button></a>";
                            }
                        ?>
                        <a href="/index.php/suppression/<?=$m['id']?>"><button class='btn-action'>supprimer</button></a>
                        <a href="/index.php/modification/<?=$m['id']?>"><button class='btn-action'>modifier</button></a>
                        </td> 
                    </tr>
                    <?php endforeach;?>
                </table>
            </div>
        </div>
        <?php
            if (isset($message)){
                echo $message;
            }
        ?>
        <?php echo $pager->links();?>
    </div>
</body>
</html>