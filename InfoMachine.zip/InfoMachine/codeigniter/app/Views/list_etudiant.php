<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liste Etudiant</title>
</head>
<body>
    <h1>LISTES DES ETUDIANT</h1>
    <table>
        <tr>
            <td>NOM</td>
            <td>PRENOM</td>
            <td>ATTRIBUTION</td>
        </tr>
        <?php foreach($etudiant as $s):?>
            <tr>
            <td><?=$s['nom']?></td>
            <td><?=$s['prenom']?></td>
            <td>
            <?php if ($s['attribution']=="oui"){
                echo "<a href='/index.php/changement/".$s['id']."/".$id_machine."'>CHANGER</a>";
            }else{
                echo "<a href='/index.php/donnation/".$s['id']."/".$id_machine."'>DONNER</a>";
            }
            ?>
            </td>
        </tr>
        <?php endforeach;?>
    </table>
</body>
</html>