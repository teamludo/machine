<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajout</title>
    <style>
        *{
        margin:0px;
        padding: 0px;
        box-sizing: border-box;
        font-family: Arial, Helvetica, sans-serif;
        }
        body {
        height: 100vh;
        font-family: 'Roboto', sans-serif;
        background: linear-gradient(to right, #7200d0, rgb(0,119,255));
        display: flex;
        justify-content: center;
        align-items: center;
        }
        form{
            width: 90%;
            max-width: 1000px;
            height: auto;
        }
        .container{
            width: 100%;
            height: auto;
            background-color: #ffffff;
            border-radius: 10px;
            display: grid;
            grid-template-columns: 1fr 1fr;
            grid-gap: 5vw;
        }

        .container-img {
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .container-img img {
            width: 80%;
            max-width: 350px;
            height: auto;
        }

        .container-form {
            display: grid;
            grid-template-columns: 1fr;
            grid-gap: 20px;
            padding: 5% 5%;
        }

        .input-container {
            background-color: #e5e5e5;
            display: flex;
            align-items: center;
            padding: 5px;
            height: 55px;
            border-radius: 30px;
            width: 90%;
        }
        .liste-container{
            width: 90%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 20px;
        }
        .liste-container a{
            text-decoration: none;
            font-size: 18px;
        }
        .input-container:hover {
            background-color: #eaeaea;
        }

        .input-field {
            color: #6b6b6b;
            background-color: inherit;
            width: 100%;
            border: none;
            font-size: 1.3rem;
            font-weight: 400;
            padding-left: 30px;
        }

        .input-field:hover,
        .input-field:focus {
            outline: none;
        }

        #input-submit {
            background-color: blueviolet;
            padding-left: 0;
            font-weight: bold;
            color: white;
            text-transform: uppercase;
            height: 45px;
            border-radius: 30px;
            width: 90%;
        }

        #input-submit:hover {
            background-color: rgb(0,119,200);
            transition: background-color 1s;
            cursor: pointer;
        }

        h1{
            text-align: center;
        }
        .container-message{
            position: absolute;
            top: 0;
            left: 0;
            z-index: 2;
            width: 100%;
            height: 100%;
            background-color: #443f3fdc;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0;
        }
        .message{
            border-radius: 20px;
            height: 25%;
            width: 25%;
            background-color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
            font-size: 30px;
            font-weight: bold;
        }
        .btn-retour{
            height: 40px;
            width: 130px;
            background-color: blue;
            color:white;
            border: none;
            border-radius: 20px;
            font-size: 20px;
            margin-top: 20px;
        }
    </style>
    <script>
function validation() {
    var mac = document.getElementById("mac").value;
    var ip = document.getElementById("ip").value;

    var macParts = mac.split(":");
    var ipParts = ip.split(".");
    var nbValidation = 1;
    // Vérification de la longueur des parties pour l'adresse MAC
    if (macParts.length !== 6) {
        alert("Adresse MAC incorrecte");
        nbValidation = 0;
    }else{
        macParts.forEach(mac=>{
            if (mac.length!=2){
                alert("Adresse MAC incorrecte");
                nbValidation = 0;
            }else{
                if (parseInt(mac,16)<0 || parseInt(mac,16)>255){
                    alert("Adresse MAC incorrecte");
                    nbValidation = 0;
                }
            }
        });
    }

    // Vérification de la longueur des parties pour l'adresse IP
    if (ipParts.length !== 4) {
        alert("Adresse IP incorrecte");
        nbValidation = 0;
    }else{
        ipParts.forEach(ip=>{
            if (parseInt(ip)<0 || parseInt(ip)>255){
                alert("Adresse IP incorrecte");
                nbValidation = 0;
            }
        });
    }   
    if(nbValidation==1){
        document.getElementById("formulaire").submit();
    } 
}
function retour(){
    let div = document.querySelector(".container-message");
    document.body.removeChild(div);
}
</script>
</head>
<body>
<form action="http://www.machine.mg/index.php/insertion" method="post" id="formulaire">
    <div class="container">
        <div class="container-img">
            <img src="icon.png" alt="icon pc"/>
        </div>
        <div class="container-form">
            <h1>AJOUT PC</h1>
            <div class="input-container">
                <i class="label"></i>
                <input placeholder="Adresse Mac" name="mac" id="mac" class="input-field"/>
            </div>
            <div class="input-container">
                <i class="label"></i>
                <input placeholder="Adresse IP" name="ip" id="ip" class="input-field"/>
            </div>
            <div class="input-container">
                <i class="label"></i>
                <input placeholder="Numéro de série" name="serie" id="serie" class="input-field"/>
            </div>
            <div class="input-container">
                <i class="label"></i>
                <input placeholder="Pan" name="pan" id="pan" class="input-field"/>
            </div>
            <div class="input-container">
                <i class="label"></i>
                <input placeholder="Etat" name="etat" id="etat" class="input-field"/>
            </div>
            <div class="input-container">
                <i class="label"></i>
                <input placeholder="Hostname" name="host" id="hostname" class="input-field"/>
            </div>
            <button id="input-submit" class="input-field" onclick="validation()" type="button">Enregistrer</button>
            <div class="liste-container">
                <a href="/index.php/list">lister les machine</a>
            </div>
        </div>
    </div>
</form>
<?php

    if (isset($message)){
        if($message=="Pas Enregistrer"){
            $color = "color:red";
        }
        else{
            $color = "color:green";
        }
        echo "<div class='container-message'>";
        echo "<div class='message'>";
        echo "<p style=$color>$message</p>";
        echo "<button onclick='retour()' class='btn-retour'>retour</button>";
        echo"</div>";
        echo "</div>";
    }
?>
</body>
</html>