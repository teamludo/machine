<?php

namespace App\Controllers;

// use App\Models\Machine as ModelsMachine;
use App\Models\Etudiant;
use App\Models\Machine;
use App\Models\Machine_Etudiant;

class Main extends BaseController
{
    public function index(): string
    {
        return view('formulaire');
    }

    public function inserer()
    {
        $mac = $this->request->getPost("mac");
        $ip = $this->request->getPost("ip");
        $serie = $this->request->getPost("serie");
        $pan = $this->request->getPost("pan");
        $etat = $this->request->getPost("etat");
        $host = $this->request->getPost("host");

        $pc = new Machine();
        $data["info"] = $pc->where("mac",$mac)
                            ->orWhere("ip" ,$ip)
                            ->orWhere("serie",$serie)
                            ->orWhere("pan",$pan)
                            ->findAll();
        if (count($data["info"])==0){
            $pc->insertion($mac, $ip, $serie, $pan, $etat, $host);
            $data["message"] = "Enregistrer";
        }else{
            $data["message"] = "Pas Enregistrer";
        }
        return view("formulaire", $data);
    }

    public function afficherList():string
    {
        $pc = new Machine();

        $pager = \Config\Services::pager();
        $data["machine"] = $pc->paginate(5);
        $data['pager'] = $pc->pager;
        return view("affichage", $data); 
    }

    public function supprimer($id)
    {
        $pc = new Machine();
        $pc->delete($id);

        $pager = \Config\Services::pager();
        $data["machine"] = $pc->paginate(4);
        $data['pager'] = $pc->pager;

        return redirect()->to("/list");

    }

    public function modifier($id):string
    {
        $pc = new Machine();
        $data['pc'] = $pc->where(["id"=>$id])->findAll();

        return view("Modification", $data); 
    }
    public function modification($id)
    {
        $mac = $this->request->getPost("mac");
        $ip = $this->request->getPost("ip");
        $serie = $this->request->getPost("serie");
        $pan = $this->request->getPost("pan");
        $etat = $this->request->getPost("etat");
        $host = $this->request->getPost("host");
        $pc = new Machine();
        $data["info"] = $pc->where("mac",$mac)
                            ->orWhere("ip",$ip)
                            ->orWhere("serie",$serie)
                            ->orWhere("pan",$pan)
                            ->findAll();
        if (count($data["info"])==1 || count($data["info"])==0){
            $pc->modification($id,$mac, $ip, $serie, $pan, $etat, $host);
            $data["message"] = "Modifier";
        }
        else{
            $data["message"] = "NON Modifier";
        }


        $pager = \Config\Services::pager();
        $data["machine"] = $pc->paginate(4);
        $data['pager'] = $pc->pager;
        // return redirect()->to('/list');
        return view("affichage" , $data);
    }

    public function attribuer($id)
    {
        $pc = new Etudiant();
        $relation = new Machine_Etudiant();
        $relation_id = $relation->findAll();
        
        $etudiants = $pc->findAll();
        //return redirect()->to("/afficherList");
        for($i = 0;$i < count($etudiants);$i++){

            $etudiants[$i]["attribution"] = "non";
            foreach($relation_id as $ri){
                if($etudiants[$i]['id'] ==  $ri["etudiant_id"]){
                    $etudiants[$i]["attribution"] = "oui";
                    break;
                }
            }
        }
        $data["etudiant"] = $etudiants;
        $data['id_machine'] = $id;

        // return "";
        return view("list_etudiant", $data);
        
    }

    public function changer($id_etudiant, $id_machine)
    {
        $relation = new Machine_Etudiant();
        $new_data = [
            "machine_id" => $id_machine,
            "etudiant_id" => $id_etudiant
        ];
        $etudiant = $relation->where(["etudiant_id" => $id_etudiant])->findAll();
        $id_old_machine = $etudiant[0]['machine_id']; 
        $relation->update($etudiant[0]['id'], $new_data); 
        
        $pc = new Machine();

        $new_data = [
            "attribution" => "oui"
        ];

        $pc->update($id_machine, $new_data);  

        $new_data = [
            "attribution" => "nom"
        ];
        $pc->update($id_old_machine, $new_data);


        return redirect()->to("/list");

    }


    public function donner($id_etudiant, $id_machine)
    {
        $relation = new Machine_Etudiant();
        $new_data = [
            "machine_id" => $id_machine,
            "etudiant_id" => $id_etudiant
        ];
        $relation->insert($new_data);
        
        $pc = new Machine();

        $new_data = [
            "attribution" => "oui"
        ];

        $pc->update($id_machine, $new_data);        

        return redirect()->to("/list");

    }

    public function desattribuer($id_machine)
    {
        $relation = new Machine_Etudiant();
        $etudiant = $relation->where(["machine_id" => $id_machine])->findAll();
        $relation->delete($etudiant[0]['id']);

        $pc = new Machine();
       $etudiant = $relation->where(["id" => $id_machine])->findAll();

       $new_data = [
        "attribution" => "non"
        ];

        $pc->update($id_machine, $new_data); 

        return redirect()->to("/list");
        // return view("affichage", $data);
    }

}

