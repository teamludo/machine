function validation() {
    var mac = document.getElementById("mac").value;
    var ip = document.getElementById("ip").value;

    var macParts = mac.split(":");
    var ipParts = ip.split(".");
    var nbValidation = 1;
    // Vérification de la longueur des parties pour l'adresse MAC
    if (macParts.length !== 6) {
        alert("Adresse MAC incorrecte");
        nbValidation = 0;
    }else{
        macParts.forEach(mac=>{
            if (mac.length!=2){
                alert("Adresse MAC incorrecte");
                nbValidation = 0;
            }else{
                if (parseInt(mac,16)<0 || parseInt(mac,16)>255 || isNaN((parseInt(mac,16)))){
                    alert("Adresse MAC incorrecte");
                    nbValidation = 0;
                }
            }
        });
    }
    
    // Vérification de la longueur des parties pour l'adresse IP
    if (ipParts.length !== 4) {
        alert("Adresse IP incorrecte");
        nbValidation = 0;
    }else{
        // console.log(parseInt(mac,16))
        ipParts.forEach(ip=>{
            if (parseInt(ip)<0 || parseInt(ip)>255 || isNaN((parseInt(ip)))){
                alert("Adresse IP incorrecte");
                nbValidation = 0;
            }
        });
    }   
    if(nbValidation==1){
        document.getElementById("formulaire").submit();
    } 
}
function retour(){
    let div = document.querySelector(".container-message");
    document.body.removeChild(div);
}
