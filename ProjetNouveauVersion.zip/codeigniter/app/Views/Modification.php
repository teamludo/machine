<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/style.css">
    <script src="/script.js"></script>
    <title>modifier</title>
</head>
<body>

<?php foreach($pc as $m):?>
<form action="/index.php/modifier/<?php echo $m['id']?>" method="post" id="formulaire">
    <div class="container">
        <div class="container-img">
            <img src="/icon.png" alt="icon pc"/>
        </div>
        <div class="container-form">
            <h1>MODIFICATION</h1>
            <div class="input-container">
                <i class="label"></i>
                <input type="text" id="mac" name="mac"  value = "<?php echo $m['mac'] ?>" placeholder="ADRESSE MAC" class="input-field" readonly>
            </div>
            <div class="input-container">
                <i class="label"></i>
                <input type="text" id="ip" name="ip"  value = "<?php echo $m['ip'] ?>" placeholder="ADRESSE IP" class="input-field" required>
            </div>
            <div class="input-container">
                <i class="label"></i>
                <input type="text"  name="serie"  value = "<?php echo $m['serie'] ?>" placeholder="NUMERO DE SERIE" class="input-field" readonly>
            </div>
            <div class="input-container">
                <i class="label"></i>
                <input type="text" name="pan"  value = "<?php echo $m['pan'] ?>" placeholder="PAN" class="input-field" readonly>
            </div>
            <div class="input-container">
                <i class="label"></i>
                <input type="text" name="etat"  value = "<?php echo $m['etat'] ?>" placeholder="ETAT" class="input-field" required>
            </div>
            <div class="input-container">
                <i class="label"></i>
                <input type="text" name="host"  value = "<?php echo $m['hostname'] ?>" placeholder="HOSTNAME" class="input-field" required>
            </div>
            <?php endforeach;?>
            <div class="div-submit" style="margin-bottom: 60px;">
                <button id="input-submit" class="input-field" onclick="validation()" type="button">Enregistrer</button>
            </div>  
        </div>
    </div>
</form>
</body>
</html>