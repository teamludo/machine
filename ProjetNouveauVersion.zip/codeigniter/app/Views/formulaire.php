<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajout</title>
    <link rel="stylesheet" href="/style.css">
    <script src="/script.js"></script>
</head>
<body>
<form action="http://www.machine.mg/index.php/insertion" method="post" id="formulaire">
    <div class="container">
        <div class="container-img">
            <img src="/icon.png" alt="icon pc"/>
        </div>
        <div class="container-form">
            <h1>AJOUT PC</h1>
            <div class="input-container">
                <i class="label"></i>
                <input placeholder="Adresse Mac" name="mac" id="mac" class="input-field" required/>
            </div>
            <div class="input-container">
                <i class="label"></i>
                <input placeholder="Adresse IP" name="ip" id="ip" class="input-field" required/>
            </div>
            <div class="input-container">
                <i class="label"></i>
                <input placeholder="Numéro de série" name="serie" id="serie" class="input-field" required/>
            </div>
            <div class="input-container">
                <i class="label"></i>
                <input placeholder="Pan" name="pan" id="pan" class="input-field"/>
            </div>
            <div class="input-container">
                <i class="label"></i>
                <input placeholder="Etat" name="etat" id="etat" class="input-field" required/>
            </div>
            <div class="input-container">
                <i class="label"></i>
                <input placeholder="Hostname" name="host" id="hostname" class="input-field" required/>
            </div>
            <button id="input-submit" class="input-field" onclick="validation()" type="button">Enregistrer</button>
            <div class="liste-container">
                <p style="margin-right: 7px;font-size:18px">voir la </p>
                <a href="/index.php/list">liste des machines</a>
            </div>
        </div>
    </div>
</form>
<?php

if (isset($message)){
    if($message=="Pas Enregistrer"){
        $color = "color:red";
    }
    else{
        $color = "color:green";
    }
    echo "<div class='container-message'>";
    echo "<div class='message'>";
    echo "<p style=$color>".$message."</p>";
    echo "<a href='/'><button onclick='retour()' class='btn-retour'>retour</button></a>";
    echo"</div>";
    echo "</div>";
}
?>
</body>
</html>