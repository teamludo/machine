<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liste Etudiant</title>
    <link href="/listeEtudiantCSS.css" rel="stylesheet"/>
</head>
<body>
    <header>
            <h1>LISTES DES ETUDIANT</h1>
            <form action="/index.php/searchEtudiant/<?=$id_machine?>" method="post">
                <div class="div-search">
                    <input type="text" placeholder="rechercher ..." name="search"/>
                    <button class="btn-search">rechercher</button>
                </div> 
            </form>
            <div class="btn-div">
                <a href="/index.php/list"><button class ="btn-nav">Retour</button></a>
                <a href="/index.php/attribution/<?=$id_machine?>"><button class ="btn-nav">Tout</button></a>
                <a href="/index.php/disponible/<?=$id_machine?>"><button class ="btn-nav">Disponible</button></a>
                <a href="/index.php/indisponible/<?=$id_machine?>"><button class ="btn-nav">Indisponible</button></a>
            </div>
    </header>

    <section  class="corps">
        <div class="div">
            <div class="princ">
                <table class="div-tr">
                    <tr class="tr-init">
                        <td>NOM</td>
                        <td>PRENOM</td>
                        <td>ATTRIBUTION</td>
                    </tr>
                </table>
                <div class="div-table">
                    <table class="table">
                        <?php foreach($etudiant as $s):?>
                            <tr>
                            <td><?=$s['nom']?></td>
                            <td><?=$s['prenom']?></td>
                            <td>
                            <?php if ($s['attribution']=="oui"){
                                echo "<a href='/index.php/changement/".$s['id']."/".$id_machine."' class='etudiant-action'>CHANGER</a>";
                            }else{
                                echo "<a href='/index.php/donnation/".$s['id']."/".$id_machine."' class='etudiant-action'>DONNER</a>";
                            }
                            ?>
                            </td>
                        </tr>
                        <?php endforeach;?>
                    </table>
                </div>
            </div>
        </div>
    </section>
</body>
</html>