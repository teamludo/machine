<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Affichage</title>
    <link rel="stylesheet" href="/afficheCSS1.css">
    <script>
        function retour(){
        let div = document.querySelector(".container-message");
        document.body.removeChild(div);
        }
    </script>    
</head>
<body>
    <header>
            <h1>LISTES DES PC</h1>
            <form action="/index.php/rechercher" method="post">
                <div class="div-search">
                    <input type="text" placeholder="rechercher ..." name="search"/>
                    <button class="btn-search">rechercher</button>
                </div> 
            </form>
            <div class="btn-div">
                <a href="/"><button class ="btn-nav">Ajout</button></a>
                <a href="/index.php/list"><button class ="btn-nav">Tout</button></a>
                <a href="/index.php/dispo"><button class ="btn-nav">Disponible</button></a>
                <a href="/index.php/indispo"><button class ="btn-nav">Indisponible</button></a>
            </div>
    </header>
    <section class="corps">
        <div class="div">
            <div class="princ">
                <table class="div-tr">
                    <tr class="tr-init">
                        <td>MAC</td>
                        <td>IP</td>
                        <td>SERIE</td>
                        <td>PAN</td>
                        <td>ETAT</td>
                        <td>HOSTNAME</td>
                        <td class="td-action">ACTION</td>
                    </tr> 
                </table>    
                <div class="div-table">
                    <table class="table">
                        <?php foreach($machine as $m):?>
                            <tr>
                            <td><?=$m['mac']?></td>
                            <td><?=$m['ip']?></td>
                            <td><?=$m['serie']?></td>
                            <td><?=$m['pan']?></td>
                            <td><?=$m['etat']?></td>
                            <td><?=$m['hostname']?></td>
                            <td class="td-action">
                            <?php
                                if ($m['attribution']=="non"){
                                    echo "<a href='/index.php/attribution/".$m['id']."'><button class='btn-action'>Attribuer</button></a>";
                                }
                                else {
                                    echo "<a href='/index.php/desattribution/".$m['id']."'><button class='btn-action'>Desattribuer</button></a>";
                                }
                            ?>
                            <a href="/index.php/suppression/<?=$m['id']?>"><button class='btn-action'>supprimer</button></a>
                            <a href="/index.php/modification/<?=$m['id']?>"><button class='btn-action'>modifier</button></a>
                            </td> 
                        </tr>
                        <?php endforeach;?>
                    </table>
                </div>
            </div>
            <?php echo $pager->links();?>
        </div>
    </section>
</body>
<?php

    if (isset($message)){
        if($message=="Non Modifier"){
            $color = "color:red";
        }
        else{
            $color = "color:green";
        }
        echo "<div class='container-message'>";
        echo "<div class='message'>";
        echo "<p style=$color>".$message."</p>";
        echo "<a href='/index.php/list'><button onclick='retour()' class='btn-retour'>Voir la liste</button></a>";
        echo"</div>";
        echo "</div>";
    }
?>
</html>