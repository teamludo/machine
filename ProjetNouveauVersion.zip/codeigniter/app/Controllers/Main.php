<?php

namespace App\Controllers;

use App\Models\Etudiant;
use App\Models\Machine;
use App\Models\Machine_Etudiant;

class Main extends BaseController
{
    public function index(): string
    {
        return view('formulaire');
    }

    public function inserer()
    {
        $mac = $this->request->getPost("mac");
        $ip = $this->request->getPost("ip");
        $serie = $this->request->getPost("serie");
        $pan = $this->request->getPost("pan");
        $etat = $this->request->getPost("etat");
        $host = $this->request->getPost("host");

        $pc = new Machine();
        $data["info"] = $pc->where("mac",$mac)
                            ->orWhere("ip" ,$ip)
                            ->orWhere("serie",$serie)
                            ->orWhere("pan",$pan)
                            ->findAll();
        if (count($data["info"])==0){
            $pc->insertion($mac, $ip, $serie, $pan, $etat, $host);
            $data["message"] = "Enregistrer";
        }else{
            $data["message"] = "Pas Enregistrer";
        }
        return view("/formulaire", $data);
    }

    public function afficherList():string
    {
        $pc = new Machine();
        $data["machine"] = $pc->paginate(5);
        $data['pager'] = $pc->pager;
        return view("affichage", $data); 
    }

    public function supprimer($id)
    {
        $pc = new Machine();
        
        $relation = new Machine_Etudiant();
        $rel = $relation->where(["machine_id" => $id])->findAll(); 
        if(count($rel)>0){
            $relation->delete($rel[0]['id']);
        }
        // var_dump($rel);

        $pc->delete($id);

        // $pager = \Config\Services::pager();
        $data["machine"] = $pc->paginate(5);
        $data['pager'] = $pc->pager;

        return redirect()->to("/list");

    }

    public function modifier($id):string
    {
        $pc = new Machine();
        $data['pc'] = $pc->where(["id"=>$id])->findAll();

        return view("Modification", $data); 
    }
    public function modification($id)
    {
        $mac = $this->request->getPost("mac");
        $ip = $this->request->getPost("ip");
        $serie = $this->request->getPost("serie");
        $pan = $this->request->getPost("pan");
        $etat = $this->request->getPost("etat");
        $host = $this->request->getPost("host");
        $pc = new Machine();
        $data["info"] = $pc->where("mac",$mac)
                            ->orWhere("ip",$ip)
                            ->orWhere("serie",$serie)
                            ->orWhere("pan",$pan)
                            ->findAll();
        if (count($data["info"])==1 || count($data["info"])==0){
            $pc->modification($id,$mac, $ip, $serie, $pan, $etat, $host);
            $mess = "Modifier";
        }
        else{
            $mess = "Non Modifier";
        }
        $data["machine"] = $pc->paginate(5);
        $data['pager'] = $pc->pager;
        $data['message'] = $mess;
        return view("affichage",$data);
    }

    public function attribuer($id)
    {
        $pc = new Etudiant();
        $relation = new Machine_Etudiant();
        $relation_id = $relation->findAll();
        
        $etudiants = $pc->findAll();
        //return redirect()->to("/afficherList");
        for($i = 0;$i < count($etudiants);$i++){

            $etudiants[$i]["attribution"] = "non";
            foreach($relation_id as $ri){
                if($etudiants[$i]['id'] ==  $ri["etudiant_id"]){
                    $etudiants[$i]["attribution"] = "oui";
                    break;
                }
            }
        }
        $data["etudiant"] = $etudiants;
        $data['id_machine'] = $id;

        // return "";
        return view("list_etudiant", $data);
        
    }

    public function changer($id_etudiant, $id_machine)
    {
        $relation = new Machine_Etudiant();
        $new_data = [
            "machine_id" => $id_machine,
            "etudiant_id" => $id_etudiant
        ];
        $etudiant = $relation->where(["etudiant_id" => $id_etudiant])->findAll();
        $id_old_machine = $etudiant[0]['machine_id']; 
        $relation->update($etudiant[0]['id'], $new_data); 
        
        $pc = new Machine();

        $new_data = [
            "attribution" => "oui"
        ];

        $pc->update($id_machine, $new_data);  

        $new_data = [
            "attribution" => "non"
        ];
        $pc->update($id_old_machine, $new_data);


        return redirect()->to("/list");

    }


    public function donner($id_etudiant, $id_machine)
    {
        $relation = new Machine_Etudiant();
        $new_data = [
            "machine_id" => $id_machine,
            "etudiant_id" => $id_etudiant
        ];
        $relation->insert($new_data);
        
        $pc = new Machine();

        $new_data = [
            "attribution" => "oui"
        ];

        $pc->update($id_machine, $new_data);        

        return redirect()->to("/list");

    }

    public function desattribuer($id_machine)
    {
        $relation = new Machine_Etudiant();
        $etudiant = $relation->where(["machine_id" => $id_machine])->findAll();
        $relation->delete($etudiant[0]['id']);

        $pc = new Machine();
        $etudiant = $relation->where(["id" => $id_machine])->findAll();

        $new_data = [
        "attribution" => "non"
        ];

        $pc->update($id_machine, $new_data); 

        return redirect()->to("/list");
        // return view("affichage", $data);
    }
    public function recherche(){
        $search = $this->request->getVar("search");
        $pc = new Machine();
        $data["machine"] = $pc->Like("mac",$search)
                              ->orLike("ip",$search)
                              ->orLike("serie",$search)
                              ->orLike("pan",$search)
                              ->orLike("hostname",$search)
                              ->paginate(5);
        $data['pager'] = $pc->pager;
        return view("affichage", $data);                       
    }
    public function disponible(){
        $pc = new Machine();
        $data["machine"] = $pc->where(["attribution"=>"non"])
                              ->paginate(5);
        $data["pager"] = $pc->pager;  
        return view("affichage",$data);                    
    }
    public function indisponible(){
        $pc = new Machine();
        $pager = \Config\Services::pager();
        $data["machine"] = $pc->where(["attribution"=>"oui"])
                              ->paginate(5);
        $data["pager"] = $pc->pager;  
        return view("affichage",$data);                    
    }

    public function dispoEtudiant($id){
        $pc = new Etudiant();
        $relation = new Machine_Etudiant();
        $relation_id = $relation->findAll();

        $list = array();
        
        
        $etudiants = $pc->findAll();
        for($i = 0;$i < count($etudiants);$i++){
            $var = 0;
            foreach($relation_id as $ri){
                if($etudiants[$i]['id'] ==  $ri["etudiant_id"]){
                    $var = 1;
                    break;
                }
            }
            if ($var==0){
                $etudiants[$i]["attribution"] = "non";
                $list[] = $etudiants[$i];
            }
        }

        $data["etudiant"] = $list;
        $data['id_machine'] = $id;
        return view("list_etudiant", $data);                    
    }
    public function indispoEtudiant($id){
        $pc = new Etudiant();
        $relation = new Machine_Etudiant();
        $relation_id = $relation->findAll();

        $list = array();
        
        $etudiants = $pc->findAll();
        for($i = 0;$i < count($etudiants);$i++){

            foreach($relation_id as $ri){
                if($etudiants[$i]['id'] ==  $ri["etudiant_id"]){
                    $etudiants[$i]["attribution"] = "oui";
                    $list[] = $etudiants[$i];
                    break;
                }
            }
        }

        $data["etudiant"] = $list;
        $data['id_machine'] = $id;
        return view("list_etudiant", $data);
    }
    public function rechercheEtudiant($id){
        $search = $this->request->getVar("search");
        $et = new Etudiant();
        $relation = new Machine_Etudiant();
        $relation_id = $relation->findAll();
        $etudiants = $et->Like("nom",$search)
                              ->orLike("prenom",$search)
                              ->paginate(5);
        for($i = 0;$i < count($etudiants);$i++){
        $etudiants[$i]["attribution"] = "non";
        foreach($relation_id as $ri){
            if($etudiants[$i]['id'] ==  $ri["etudiant_id"]){
                $etudiants[$i]["attribution"] = "oui";
                break;
            }
        }
    }    
        $data["etudiant"] = $etudiants;                  
        $data['pager'] = $et->pager;
        $data['id_machine'] = $id;
        return view("list_etudiant", $data);
    }
}

