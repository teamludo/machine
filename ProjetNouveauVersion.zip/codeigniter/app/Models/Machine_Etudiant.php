<?php 
namespace App\Models;
use CodeIgniter\Model;
class Machine_Etudiant extends Model
{
    protected $table = "Machine_Etudiant";
    protected $allowedFields = ["machine_id", "etudiant_id"];
    
}
?>